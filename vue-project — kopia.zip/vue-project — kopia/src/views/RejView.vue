<script setup>
import Rej from '../components/RejComponent.vue'
</script>

<template>
  <main>
    <div>
      <h1 class="DarekStyle">Rejestracja do aplikacji</h1>
      <Rej />
    </div>
  </main>
</template>

<style scoped>
div {
  text-align: center;
  margin: auto;
  width: 100%;
  border: 3px solid green;
  padding: 10px;
  background-color: black;
}
.DarekStyle {
  font-size: 76px;
  line-height: 1.25;
  font-weight: 900;
  letter-spacing: -1.5px;
  max-width: 960px;
  margin: 0 auto;
  text-align: center;
  background: -webkit-linear-gradient(315deg, #42d392 25%, #647eff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  padding: 5px;
}
</style>
