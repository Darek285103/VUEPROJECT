<script setup>

</script>

<template>
  <main>
    <h1 class="DarekStyle">HOME</h1>

  </main>
</template>

<style>
.DarekStyle {
  font-size: 76px;
  line-height: 2;
  font-weight: 900;
  letter-spacing: -1.5px;
  max-width: 960px;
  margin: 0 auto;
  text-align: center;
  background: -webkit-linear-gradient(315deg, #42d392 25%, #647eff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  padding: 5px;
}
</style>
