<template>
  <div class="container">
    <form @submit.prevent="login">
      <h2 class="mb-3">Logowanie</h2>
      <div class="input">
        <label for="email">Adres e-mail</label>
        <input class="form-control" type="text" name="email" placeholder="Wprowadź adres e-mail" />
      </div>
      <div class="input">
        <label for="password">Hasło</label>
        <input class="form-control" type="password" name="password" placeholder="Wprowadź hasło" />
      </div>

      <button type="submit" class="mt-4 btn-pers" id="login_button">Zaloguj</button>

      <div class="alternative-option mt-4">
        nie masz konta? <span @click="doRejestracji">Zarejestruj się</span>
      </div>
    </form>
  </div>
</template>

<script>
import { getAuth, signInWithEmailAndPassword } from 'firebase/auth'
import { initializeApp } from 'firebase/app'

export default {
  data() {
    return {
      email: '',
      password: '',
      firebaseConfig: {
        apiKey: 'AIzaSyC7iHgYq7WbHkaF_8VlFEzPT5EZxZi6euY',
        authDomain: 'pspizk-my-app.firebaseapp.com',
        projectId: 'pspizk-my-app',
        storageBucket: 'pspizk-my-app.appspot.com',
        messagingSenderId: '383308671313',
        appId: '1:383308671313:web:e877f1efc7709eea958b70'
      }
    }
  },
  methods: {
    login(submitEvent) {
      this.email = submitEvent.target.elements.email.value
      this.password = submitEvent.target.elements.password.value

      const app = initializeApp(this.firebaseConfig)
      const auth = getAuth(app)
      signInWithEmailAndPassword(auth, this.email, this.password)
        .then(() => {
          this.$router.push('/')
          console.log('Logowanie udane')
        })
        .catch((error) => {
          const errorCode = error.code
          const errorMessage = error.message
          console.log(errorCode)
          console.log(errorMessage)
        })
    },
    doRejestracji() {
      this.$router.push('/Rejestracja')
    }
  }
}
</script>

<style scoped>
.container {
  width: 400px;
  max-width: 90%;
  padding: auto;
  background-color: black;
}

.input {
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
  color: aliceblue;
}

.input > label {
  text-align: start;
}

.input > input {
  margin-top: 6px;
  height: 38px !important;
}
.btn-pers {
  position: center;
  padding: 1em 2.5em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 700;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}
.btn-pers:hover {
  background-color: #198754;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
}
.alternative-option {
  text-align: center;
}

.alternative-option > span {
  color: #0d6efd;
  cursor: pointer;
}
</style>
