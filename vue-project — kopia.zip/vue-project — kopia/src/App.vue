<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <div class="background">
    <div class="head">
      <h1 class="DarekStyle">Aplikacja SAP</h1>
        <nav class="rozmieszczenie">
          <button class="mt-4 btn-pers">
          <RouterLink to="/">Home</RouterLink>
          </button>
          <button class="mt-4 btn-pers">
          <RouterLink to="/APICF">API Cat Facts</RouterLink>
          </button>
          <button class="mt-4 btn-pers">
          <RouterLink to="/Logowanie">Logowanie</RouterLink>
          </button>
          <button class="mt-4 btn-pers">
          <RouterLink to="/Rejestracja">Rejestracja</RouterLink>
          </button>
        </nav>
    </div>  
    <div>
      <RouterView />
    </div>
  </div>
</template>

<style scoped>

.rozmieszczenie{
width:  90%;
padding: 10px auto;
margin-bottom: 2%;
padding-bottom: 2%;
margin: auto;
}

.background {
  margin: auto;
  padding: auto;
  background-color: black;
  max-width: max-content;
  max-height: 100%;
}
.DarekStyle {
  font-size: 76px;
  line-height: 1.25;
  font-weight: 900;
  letter-spacing: -1.5px;
  max-width: 960px;
  margin: 0 auto;
  text-align: center;
  background: -webkit-linear-gradient(315deg, #42d392 25%, #647eff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.btn-pers {
  position: center;
  padding: 1em 2.5em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 700;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
  margin: 2%;
}
.btn-pers:hover {
  background-color: #198754;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
}
</style>
