import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import APICatFact from '../views/APICFView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/APICF',
      name: 'APICF',
      component: APICatFact
    },
    {
      path: '/Logowanie',
      name: 'Logowanie',
      component: () => import('../views/logView.vue')
    },
    {
      path: '/Rejestracja',
      name: 'Rejestracja',
      component: () => import('../views/RejView.vue')
    },
  ]
})

export default router
