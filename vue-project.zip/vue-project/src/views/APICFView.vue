<script>
export default {
  data() {
    return {
      res: 'Click Button!'
    }
  },
  methods: {
    fetchData() {
      fetch('https://cat-facts12.p.rapidapi.com/Fact', {
        method: 'GET',
        headers: {
          'x-rapidapi-host': 'cat-facts12.p.rapidapi.com',
          'x-rapidapi-key': '3ae885c34dmsh2a2d68bd8a84a22p13eb97jsn144a5646a5c3'
        }
      })
        .then((response) => {
          response.json().then((res) => console.log((this.res = res.Fact)))
        })
        .catch((err) => {
          console.error(err)
        })
    }
  }
}
</script>

<template>
  <div>
    <h1 class="DarekStyle">API Cat Facts</h1>
    <button class="mt-4 btn-pers" @click="fetchData">Click Me to get Cat fact!</button>
    <h2 class="text">Czasem trzeba chwile poczekać</h2>
    <h2 class="text">CAT FACT:</h2>
    <h3 class="text">{{ res }}</h3>
  </div>
</template>

<style scoped>

.text{
  color: aliceblue;
}

div {
  text-align: center;
  margin: auto;
  width: 100%;
  border: 3px solid green;
  padding: auto;
  background-color: black;
}

.btn-pers {
  position: center;
  padding: 1em 2.5em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 700;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}
.btn-pers:hover {
  background-color: #198754;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
}
.DarekStyle {
  font-size: 76px;
  line-height: 1.25;
  font-weight: 900;
  letter-spacing: -1.5px;
  max-width: 960px;
  margin: 0 auto;
  text-align: center;
  background: -webkit-linear-gradient(315deg, #42d392 25%, #647eff);
  background-clip: text;
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
</style>
