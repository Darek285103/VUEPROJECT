<template>
  <div class="container">
    <form @submit.prevent="register">
      <h2 class="mb-3">Rejestracja</h2>
      <div class="input">
        <label for="email">Email address</label>
        <input class="form-control" type="text" name="email" placeholder="email@adress.com" />
      </div>
      <div class="input">
        <label for="email">Imie</label>
        <input class="form-control" type="text" name="imie" placeholder="Jan" />
      </div>
      <div class="input">
        <label for="email">Nazwisko</label>
        <input class="form-control" type="text" name="nazwisko" placeholder="Kowalski" />
      </div>
      <div class="input">
        <label for="password">Password</label>
        <input class="form-control" type="password" name="password" placeholder="password123" />
      </div>

      <button type="submit" id="register_button" class="mt-4 btn-pers">Rejestruj</button>

      <div class="alternative-option mt-4">
        Masz już konto? <span @click="doLogowania">Zaloguj się</span>
      </div>
    </form>
  </div>
</template>

<script>
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth'
import { initializeApp } from 'firebase/app'

export default {
  data() {
    return {
      email: '',
      password: '123456',
      firebaseConfig: {
        apiKey: 'AIzaSyC7iHgYq7WbHkaF_8VlFEzPT5EZxZi6euY',
        authDomain: 'pspizk-my-app.firebaseapp.com',
        projectId: 'pspizk-my-app',
        storageBucket: 'pspizk-my-app.appspot.com',
        messagingSenderId: '383308671313',
        appId: '1:383308671313:web:e877f1efc7709eea958b70'
      }
    }
  },
  methods: {
    register(submitEvent) {
      // data update
      this.email = submitEvent.target.elements.email.value
      this.password = submitEvent.target.elements.password.value

      const app = initializeApp(this.firebaseConfig)
      const auth = getAuth(app)
      createUserWithEmailAndPassword(auth, this.email, this.password)
        .then((userCredential) => {
          const user = userCredential.user
          console.log(user)
          console.log('Rejestracja udana')
          this.$router.push('/')
        })
        .catch((error) => {
          const errorCode = error.code
          const errorMessage = error.message
          console.log(errorCode)
          console.log(errorMessage)
        })
    },
    doLogowania() {
      this.$router.push('/Logowanie')
    }
  }
}
</script>

<style scoped>
.container {
  width: 400px;
  max-width: 90%;
  padding: auto;
}

.input {
  display: flex;
  flex-direction: column;
  margin-bottom: 20px;
  color: aliceblue;
}
.input > label {
  text-align: start;
}
.input > input {
  margin-top: 10px;
  height: 38px !important;
}
.btn-pers {
  position: center;
  padding: 1em 2.5em;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 2.5px;
  font-weight: 700;
  color: #000;
  background-color: #fff;
  border: none;
  border-radius: 45px;
  box-shadow: 0px 8px 15px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease 0s;
  cursor: pointer;
  outline: none;
}
.btn-pers:hover {
  background-color: #198754;
  box-shadow: 0px 15px 20px rgba(46, 229, 157, 0.4);
  color: #fff;
}

.alternative-option {
  text-align: center;
}
.alternative-option > span {
  color: #0d6efd;
  cursor: pointer;
}
</style>
